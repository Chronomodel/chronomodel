Procedure to install the calibration files
- If you are on windowsOS
 double click on the file installCurves_winOS.bat
 
 or in a terminal (command prompt), go to the directory containing the file installCurves_winOS.bat
 and run : installCurves_winOS.bat
 
- If you are on macOs
 in a terminal, go to the directory containing the file installCurves_macOS.sh
 and run: sh installCurves_macOS.sh